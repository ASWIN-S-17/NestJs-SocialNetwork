import {Module} from "@nestjs/common";
import{JwtModule} from '@nestjs/jwt';
import { MulterModule } from "@nestjs/platform-express";
import { diskStorage } from "multer";
import { PrismaModule } from "../prisma/prisma.module";

import { AuthController } from "./auth.controller";
import { AuthService } from "./auth.services";
import { JwtStrategy } from "./strategy";

@Module({
    imports:[PrismaModule,JwtModule.register({}),
       /* MulterModule.register({
            storage: diskStorage({
                destination:'./fileImages',
            })})*/],
    controllers: [AuthController],
    providers: [AuthService,JwtStrategy],
})


export class AuthModule{}
