import { Body, Controller, HttpCode, HttpStatus, Post, UploadedFile, UseInterceptors } from "@nestjs/common";
import { FileInterceptor } from "@nestjs/platform-express/multer";
import multer, { diskStorage } from "multer";
import { AuthService } from "./auth.services";
import { AuthDto,LoginDto} from "./dto";




@Controller('auth')
export class AuthController {
    constructor(private authService: AuthService) { }


    @Post('register')
    register(@Body() dto:AuthDto) {
        

        return this.authService.register(dto)
    }
    @HttpCode(HttpStatus.OK)
    @Post('signin')
    signin(@Body() dto:LoginDto) {
        return this.authService.signin(dto)
    }

    @Post('createPost')
    @UseInterceptors(
        FileInterceptor('photo',{
         //   storage: diskStorage({
                dest:'./uploads',
         //   }),
            
        }))
    public uploadFile(@UploadedFile() file: any){
    
       console.log('file',file)
       
       
        return "success";
    }
   /* createPost() {
        return this.authService.createPost()
    }*/


}



