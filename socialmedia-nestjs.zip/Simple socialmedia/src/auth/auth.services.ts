import { ForbiddenException, Injectable, Res } from "@nestjs/common";
import { PrismaClientKnownRequestError } from "@prisma/client/runtime";
import * as argon from 'argon2';
import { PrismaService } from "../prisma/prisma.service";
import { AuthDto, LoginDto } from "./dto";
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';


@Injectable({})

export class AuthService {
    constructor(
        private prisma: PrismaService,
        private jwt: JwtService,
        private config: ConfigService

    ) { }

    async register(dto: AuthDto) {
        //password hash
        const password = await argon.hash(dto.password);
        console.log(dto);

        //save user in db
        try {
            const user = await this.prisma.user.create({
                data:
                {
                    name: dto.name,
                    username: dto.username,
                    email: dto.email,
                    password,
                },
            })
            //return saved user
            return this.signToken(user.id, user.name, user.email);
        }
        catch (error) {
            if (error instanceof PrismaClientKnownRequestError) {
                if (error.code === 'P2002') {
                    throw new ForbiddenException(
                        'Username or Email already exits!!! Please try again',
                    );
                }
            }
            throw error;
        }

    }

    async signin(dto: LoginDto) {
        //find the user by email
        const user = await this.prisma.user.findFirst({
            where: { email: dto.email }
        })

        //if user doesnot exist throw exception
        if (user == null) {
            throw new ForbiddenException('Not an registered Email',);

        }
        //compare password
        const isMatch = await argon.verify(user.password, dto.password);
        //if password notmatch throw exception
        if (!isMatch) {
            throw new ForbiddenException('incorrect password',);
        }
        //returning the user
        return { success: true, "Welcome!!!!": user.username };
        // return this.signToken(user.id,user.name,user.email);

    }
    async signToken(userId: number, name: string, email: string): Promise<{ access_token: string }> {

        const payload = {
            sub: userId,
            email
        }
        const secret = this.config.get('JWT_SECRET')
        const token = await this.jwt.signAsync(payload, {
            expiresIn: '30m',
            secret: secret,
        });
        return {
            access_token: token
        };

    }
    
}

